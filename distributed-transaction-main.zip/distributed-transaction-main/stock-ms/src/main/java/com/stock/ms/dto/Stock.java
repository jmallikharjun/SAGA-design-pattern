package com.stock.ms.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Stock {

	private String item;

	private int quantity;

}
